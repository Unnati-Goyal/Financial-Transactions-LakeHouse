CREATE TABLE [dbo].[l2_customer_aggregated_metrics] (

	[CUSTOMER_ID] varchar(8000) NULL, 
	[NO_TXN] bigint NULL, 
	[TOT_TRAN_AMT] float NULL, 
	[AVG_TRAN_AMT] float NULL, 
	[MIN_TRAN_AMT] float NULL, 
	[MAX_TRAN_AMT] float NULL, 
	[LAST_TXN_TIMESTMP] datetime2(6) NULL, 
	[FRAUD_RATE] float NULL, 
	[RISK_CATEGORY] varchar(2048) NULL, 
	[LAST_UPDATED_ON] date NULL
);