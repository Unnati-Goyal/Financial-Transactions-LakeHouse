CREATE TABLE [dbo].[l1_merchant_dim] (

	[MERCHANT_ID] varchar(8000) NULL, 
	[MERCHANT_CATEGORY] varchar(8000) NULL, 
	[ETL_INSERT_DATE] date NULL, 
	[VALID_FROM] date NULL, 
	[VALID_TO] date NULL, 
	[IS_CURRENT] int NULL
);