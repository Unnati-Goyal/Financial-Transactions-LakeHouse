CREATE TABLE [dbo].[l1_customer_dim] (

	[CUSTOMER_ID] varchar(8000) NULL, 
	[FIRST_NAME] varchar(8000) NULL, 
	[LAST_NAME] varchar(8000) NULL, 
	[GENDER] varchar(8000) NULL, 
	[AGE] int NULL, 
	[AGE_BUCKET] varchar(8000) NULL, 
	[CITY] varchar(8000) NULL, 
	[STATE] varchar(8000) NULL, 
	[CUSTOMER_EMAIL] varchar(8000) NULL, 
	[CUSTOMER_CONTACT] varchar(8000) NULL, 
	[CUSTOMER_COUNTRYCODE] varchar(8000) NULL, 
	[ETL_INSERT_DATE] date NULL, 
	[VALID_FROM] date NULL, 
	[VALID_TO] date NULL, 
	[IS_CURRENT] int NULL
);